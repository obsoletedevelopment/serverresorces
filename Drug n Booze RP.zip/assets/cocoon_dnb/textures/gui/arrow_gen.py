string = "{\"predicate\": {\"custom_model_data\":74500[NUMBER]}, \"model\": \"cocoon_fs:gui/left_arrow_[NUMBER]\"}"
i = 0
string_arr = []

while i <= 22:
    string_arr.append(string.replace("[NUMBER]",str(i)))
    i = i + 1
print(string_arr)
