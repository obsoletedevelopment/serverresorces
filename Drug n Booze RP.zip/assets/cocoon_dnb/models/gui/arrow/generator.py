import json
original = json.load(open("arrow_1.json","r"))

for i in range(21):
    with open("arrow_"+str(i+1)+".json","w+") as newFile:
        new_json = original
        new_json["elements"][0]["from"][1] = 5+i
        new_json["elements"][0]["faces"]["south"]["uv"][3] = 13.5 - i * 0.5
        newFile.write(json.dumps(new_json, indent=4))
    
print("completed :D")
